<?php
	
// įtraukiame šabloną
include 'templates/report_list.tpl.php';

?>