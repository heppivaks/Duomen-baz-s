<?php

class config {
	const DB_SERVER    = 'localhost';
	const DB_NAME      = 'autonuoma_min';
	const DB_USERNAME  = 'root';
	const DB_PASSWORD  = 'h64g6fgdfg';
	const DB_PREFIX	   = 'pavyzdys_';
	const NUMBER_OF_ROWS_IN_PAGE = 10;
}

?>
