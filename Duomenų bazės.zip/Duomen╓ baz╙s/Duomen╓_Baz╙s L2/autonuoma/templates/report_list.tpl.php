<ul id="pagePath">
	<li><a href="index.php">Pradžia</a></li>
	<li>Ataskaitos</li>
</ul>
<div id="actions">
	
</div>
<div class="float-clear"></div>

<div class="page">
	<ul class="reportList">
		<li>
			<p>
				<a href="index.php?module=contract&action=report" title="Sutarčių ataskaita">Sutarčių ataskaita</a>
			</p>
			<p>Nurodytu laikotarpiu sudarytų sutarčių ataskaita.</p>
		</li>
		<li>
			<p>
				<a href="index.php?module=service&action=report" title="Užsakytų paslaugų ataskaita">Užsakytų paslaugų ataskaita</a>
			</p>
			<p>Nurodytu laikotarpiu užsakytų papildomų paslaugų ataskaita.</p>
		</li>
		<li>
			<p>
				<a href="index.php?module=contract&action=report_delayed_cars" title="Vėluojamų grąžinti automobilių ataskaita">Vėluojamų grąžinti automobilių ataskaita</a>
			</p>
			<p>Negrąžintų arba pavėluotai grąžintų automobilių ataskaita.</p>
		</li>
	</ul>
</div>